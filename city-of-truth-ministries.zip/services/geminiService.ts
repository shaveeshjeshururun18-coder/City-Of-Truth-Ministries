import { GoogleGenAI } from "@google/genai";

export const getSpiritualEncouragement = async (topic: string): Promise<string> => {
  try {
    // Initialize inside the function to be safer with environment variable availability
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide a short, encouraging spiritual word and a relevant Bible verse (with citation) for someone struggling with or seeking guidance on: ${topic}. Speak as a warm, supportive ministry leader from City of Truth Ministries.`,
      config: {
        systemInstruction: "You are a warm, encouraging spiritual leader. Your goal is to provide comfort and biblical truth. Keep responses concise (under 100 words), focused on hope, and always include one specific scripture reference.",
        temperature: 0.7,
        topP: 0.9,
      },
    });

    // Accessing the .text property directly as per Google GenAI SDK rules
    return response.text || "May God's peace be with you. Please reach out to our ministry for further prayer.";
  } catch (error) {
    console.error("Error fetching spiritual encouragement:", error);
    return "The Lord is near to the brokenhearted. Stay strong in faith. (Psalm 34:18)";
  }
};