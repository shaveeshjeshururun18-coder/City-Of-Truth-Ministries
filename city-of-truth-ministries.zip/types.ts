
export enum ViewState {
  HOME = 'HOME',
  ABOUT = 'ABOUT',
  MINISTRIES = 'MINISTRIES',
  ID_CARD = 'ID_CARD',
  MENORAH = 'MENORAH',
  CONTACT = 'CONTACT',
  ABOUT_VALPARAI = 'ABOUT_VALPARAI',
  HEBREW = 'HEBREW',
  DEVELOPER = 'DEVELOPER'
}

export interface NavItem {
  label: string;
  view: ViewState;
}

export interface MemberData {
  name: string;
  email: string;
  dob: string;
  location: string;
  gender: string;
  bloodGroup: string;
  memberSince: string;
  emergency: string;
  role: string;
}
