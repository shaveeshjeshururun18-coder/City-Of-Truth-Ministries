import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Church, 
  MapPin, 
  Clock, 
  ArrowRight, 
  Youtube, 
  Instagram,
  Facebook,
  Mail, 
  Phone, 
  Heart,
  Music,
  Users,
  User,
  Star,
  Send,
  Mountain,
  History,
  Leaf,
  TrendingUp,
  CloudRain,
  Plane,
  BookOpen,
  ExternalLink,
  Camera,
  Droplets,
  Waves,
  Navigation,
  Sparkles,
  Scroll,
  MessageCircle,
  Briefcase,
  Headset,
  Cloud,
  Zap,
  Flame,
  Award,
  Video,
  Play,
  ShieldCheck,
  ChevronRight,
  RefreshCw,
  UploadCloud,
  CheckCircle
} from 'lucide-react';
import { ViewState } from './types.ts';
import { Navbar } from './components/Navbar.tsx';
import { Button } from './components/Button.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { SpiritualAssistant } from './components/SpiritualAssistant.tsx';
import { WorshipperIDCard } from './components/WorshipperIDCard.tsx';
import { GoldenMenorah } from './components/GoldenMenorah.tsx';

const hebrewLetters = [
  { letter: "א", name: "Aleph", sound: "Silent", meaning: "Ox / Strength" },
  { letter: "ב", name: "Bet", sound: "B / V", meaning: "House / Family" },
  { letter: "ג", name: "Gimel", sound: "G", meaning: "Camel / Divine" },
  { letter: "ד", name: "Dalet", sound: "D", meaning: "Door / Pathway" },
  { letter: "ה", name: "Hey", sound: "H", meaning: "Window / Behold" },
  { letter: "ו", name: "Vav", sound: "V / O / U", meaning: "Nail / Connection" },
  { letter: "ז", name: "Zayin", sound: "Z", meaning: "Weapon / Spirit" },
  { letter: "ח", name: "Chet", sound: "CH", meaning: "Fence / Inner Room" },
  { letter: "ט", name: "Tet", sound: "T", meaning: "Snake / Basket" },
  { letter: "י", name: "Yod", sound: "Y / I", meaning: "Hand / Work" },
  { letter: "כ", name: "Kaf", sound: "K / KH", meaning: "Palm / Open" },
  { letter: "ל", name: "Lamed", sound: "L", meaning: "Staff / Teach" },
  { letter: "מ", name: "Mem", sound: "M", meaning: "Water / Chaos" },
  { letter: "נ", name: "Nun", sound: "N", meaning: "Fish / Life" },
  { letter: "ס", name: "Samekh", sound: "S", meaning: "Prop / Support" },
  { letter: "ע", name: "Ayin", sound: "Silent", meaning: "Eye / Vision" },
  { letter: "פ", name: "Pei", sound: "P / F", meaning: "Mouth / Speak" },
  { letter: "צ", name: "Tzadi", sound: "TZ", meaning: "Hook / Desire" },
  { letter: "ק", name: "Kof", sound: "K", meaning: "Back of Head" },
  { letter: "ר", name: "Resh", sound: "R", meaning: "Head / Person" },
  { letter: "ש", name: "Shin", sound: "SH / S", meaning: "Teeth / Fire" },
  { letter: "ת", name: "Tav", sound: "T", meaning: "Cross / Covenant" },
];

const youtubeLink = "https://youtube.com/@cityoftruthministries";

const RevealText: React.FC<{ text: string; className?: string; delay?: number }> = ({ text, className = "", delay = 0 }) => {
  return (
    <div className={`overflow-hidden ${className}`}>
      <motion.span
        initial={{ y: "100%" }}
        whileInView={{ y: 0 }}
        transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
        viewport={{ once: true }}
        className="block"
      >
        {text}
      </motion.span>
    </div>
  );
};

// LIGHT THEMED TESTIMONIAL SECTION
const TestimonialSection = () => {
  return (
    <section className="py-24 relative z-10 overflow-hidden bg-slate-50">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 pointer-events-none"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-brand-950 mb-4">Voices of Faith</h2>
          <p className="text-slate-600 max-w-2xl mx-auto text-lg font-normal mb-8">Hear how City of Truth Ministries is impacting lives in Valparai and beyond.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Integrated Form Side - Light Theme */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-xl"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="bg-brand-600 p-3 rounded-2xl text-white shadow-lg">
                <MessageCircle size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-serif font-bold text-brand-950">Share Your Testimony</h3>
                <p className="text-sm text-slate-500">Your story can be a beacon for someone else.</p>
              </div>
            </div>
            <form className="space-y-4" onSubmit={e => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" placeholder="Your Name" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl outline-none focus:border-brand-500 transition-colors text-brand-950 placeholder:text-slate-400" />
                <input type="text" placeholder="Location" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl outline-none focus:border-brand-500 transition-colors text-brand-950 placeholder:text-slate-400" />
              </div>
              <textarea placeholder="Tell us about your encounter with God's truth..." className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl outline-none focus:border-brand-500 transition-colors text-brand-950 placeholder:text-slate-400 h-40"></textarea>
              <Button variant="primary" fullWidth className="py-4 shadow-xl shadow-brand-500/20">
                Send Testimony <Send size={18} />
              </Button>
            </form>
          </motion.div>

          {/* Testimonials List Side - Light Theme */}
          <div className="space-y-6">
            {[
              { name: "Sarah J.", role: "Member", text: "This ministry has completely transformed my spiritual life. The community in Valparai is so welcoming and the teachings are profound.", rating: 5 },
              { name: "David K.", role: "Visitor", text: "A beautiful place to worship amidst the hills. The presence of God is tangible here from the first prayer.", rating: 5 },
              { name: "Priya M.", role: "Volunteer", text: "Wonderful service and amazing youth programs. Blessed to be part of this family and grow in His truth.", rating: 5 }
            ].map((t, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-8 rounded-3xl shadow-md border border-slate-100 hover:shadow-xl transition-all group"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-brand-50 flex items-center justify-center text-brand-600 font-bold border border-brand-100">
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-brand-950 leading-none">{t.name}</h4>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-brand-600 mt-1 block">{t.role}</span>
                    </div>
                  </div>
                  <div className="flex gap-0.5">
                    {[...Array(5)].map((_, starI) => (
                      <Star key={starI} size={12} className={`${starI < Math.floor(t.rating) ? "text-amber-500 fill-amber-500" : "text-slate-200"}`} />
                    ))}
                  </div>
                </div>
                <p className="text-slate-600 italic leading-relaxed font-serif">"{t.text}"</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  const getThemeClass = () => {
    switch (currentView) {
      case ViewState.HOME: return "bg-brand-950 text-white";
      case ViewState.ABOUT: return "bg-[#fdfcf0] text-brand-950";
      case ViewState.ABOUT_VALPARAI: return "bg-slate-50 text-brand-950";
      case ViewState.MINISTRIES: return "bg-[#f0f9ff] text-sky-950";
      case ViewState.HEBREW: return "bg-black text-amber-500";
      case ViewState.ID_CARD: return "bg-[#f8fafc] text-slate-950";
      case ViewState.CONTACT: return "bg-[#f5f3ff] text-indigo-950";
      case ViewState.MENORAH: return "bg-brand-950 text-white";
      default: return "bg-white text-brand-950";
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.15 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  const letterContainer = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const letterChild = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className={`min-h-screen transition-colors duration-1000 ease-in-out font-sans ${getThemeClass()}`}>
      <Navbar 
        currentView={currentView} 
        setView={setCurrentView} 
        onLoginClick={() => setIsAuthOpen(true)}
      />
      
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />

      <main className="relative">
        <AnimatePresence mode="wait">
        {currentView === ViewState.HOME && (
          <motion.div 
            key="home"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          >
            <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden py-20">
              <div className="absolute inset-0 z-0">
                <img 
                  src="https://images.unsplash.com/photo-1438232992991-995b7058bbb3?q=80&w=2673&auto=format&fit=crop" 
                  alt="Worship Background" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-brand-900/95 via-brand-900/60 to-brand-900/95 mix-blend-multiply" />
                <div className="absolute inset-0 bg-black/40" />
              </div>

              <div className="relative z-10 text-center px-4 md:px-6 max-w-7xl mx-auto w-full pt-16">
                <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}>
                  <div className="inline-block mb-6 px-6 py-2.5 rounded-full border border-accent-400/30 bg-black/40 backdrop-blur-xl shadow-lg">
                    <span className="text-accent-300 font-bold tracking-[0.25em] uppercase text-[10px] md:text-xs">Divine Grace Sanctuary</span>
                  </div>
                  
                  <div className="flex flex-col items-center justify-center mb-10 relative">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] h-[90%] bg-accent-500/20 blur-[100px] rounded-full -z-10"></div>
                    <h2 className="text-xl md:text-3xl text-brand-100 font-serif italic tracking-wide mb-3 drop-shadow-md">City of Truth Ministries</h2>
                    <h1 className="font-bold tracking-tight leading-none py-4">
                      <span className="block text-6xl sm:text-8xl md:text-9xl text-transparent bg-clip-text bg-gradient-to-b from-brand-50 via-brand-100 to-brand-200 drop-shadow-2xl pb-4">சத்திய நகரம்</span>
                      <span className="block text-3xl sm:text-5xl md:text-6xl text-transparent bg-clip-text bg-gradient-to-br from-white via-accent-100 to-brand-300 mt-2 tracking-tighter">ஊழியங்கள்</span>
                    </h1>
                  </div>
                  
                  <p className="text-lg md:text-xl text-brand-50/80 max-w-2xl mx-auto mb-12 leading-relaxed font-light font-serif italic px-6">"Then you will know the truth, and the truth will set you free." <br/>— John 8:32</p>
                  
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-5 w-full px-6 sm:px-0">
                    <Button onClick={() => setCurrentView(ViewState.MINISTRIES)} className="w-full sm:w-auto px-10 py-4 text-xs uppercase tracking-widest bg-brand-600 hover:bg-brand-500 shadow-xl border-0 text-white font-bold">Explore Ministries</Button>
                    <Button variant="outline" onClick={() => setCurrentView(ViewState.ID_CARD)} className="w-full sm:w-auto px-10 py-4 text-xs uppercase tracking-widest border-white/40 text-white hover:bg-white hover:text-brand-900 backdrop-blur-md font-bold">Get Your ID Card</Button>
                  </div>
                </motion.div>
              </div>
            </section>

             <section className="py-24 bg-gray-50 overflow-hidden relative">
               <div className="absolute top-0 right-0 w-[40%] h-full bg-white -skew-x-12 translate-x-32 z-0 hidden lg:block"></div>

               <div className="container mx-auto px-6 relative z-10">
                 <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
                   
                   <motion.div 
                     initial={{ opacity: 0, x: -50 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     viewport={{ once: true }}
                     className="relative mx-auto lg:mx-0 max-w-lg lg:max-w-none"
                   >
                      <div className="relative z-10 rounded-[2rem] overflow-hidden shadow-2xl border-[6px] border-white">
                        <img 
                          src="https://images.unsplash.com/photo-1510590337019-5ef2d39aa786?q=80&w=2670&auto=format&fit=crop"
                          alt="Community gathering"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="absolute -bottom-16 -right-16 w-3/4 rounded-2xl overflow-hidden shadow-2xl border-[6px] border-white z-20 hidden md:block">
                         <img 
                            src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?q=80&w=2670&auto=format&fit=crop"
                            alt="Worship Moment"
                            className="w-full h-full object-cover"
                         />
                      </div>

                      <div className="absolute -top-10 -left-10 w-40 h-40 bg-accent-500 rounded-full blur-[80px] opacity-20"></div>
                      <div className="absolute bottom-10 -left-10 z-30 bg-white p-6 rounded-2xl shadow-xl shadow-brand-900/10 animate-[bounce_3s_infinite]">
                        <div className="flex items-center gap-4">
                           <div className="bg-brand-50 p-3 rounded-full text-brand-600"><Users size={24}/></div>
                           <div>
                              <p className="text-3xl font-bold text-dark-900 leading-none">500+</p>
                              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mt-1">Active Members</p>
                           </div>
                        </div>
                      </div>
                   </motion.div>

                   <motion.div
                     initial={{ opacity: 0, x: 50 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     viewport={{ once: true }}
                     className="text-left"
                   >
                      <div className="flex items-center gap-2 mb-4">
                        <span className="w-12 h-1 bg-accent-500 rounded-full"></span>
                        <span className="text-brand-600 font-bold uppercase tracking-wider text-sm">Who We Are</span>
                      </div>
                      
                      <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-dark-900 mb-6 leading-[1.1]">
                        Walking in <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-brand-400">Truth</span> & <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-500 to-accent-400">Love</span>
                      </h2>
                      
                      <p className="text-gray-600 text-lg leading-relaxed mb-8">
                        City of Truth Ministries is more than just a building—it's a family. We are dedicated to creating a space where lives are transformed by the power of the Gospel. We believe in authenticity, community, and the move of the Holy Spirit.
                      </p>
                      
                      <div className="space-y-4 mb-10">
                         {['Bible-Centered Teaching', 'Authentic Community', 'Spirit-Filled Worship'].map((item, i) => (
                           <div key={i} className="flex items-center gap-4 group cursor-default">
                             <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-600 group-hover:bg-brand-600 group-hover:text-white transition-colors duration-300">
                               <ChevronRight size={16} strokeWidth={3} />
                             </div>
                             <span className="font-semibold text-gray-800 text-lg">{item}</span>
                           </div>
                         ))}
                      </div>

                      <div className="flex flex-wrap gap-4">
                        <Button onClick={() => setCurrentView(ViewState.ABOUT)} variant="primary" className="shadow-brand-500/30 px-8 py-4 text-base">Read Our Story</Button>
                      </div>
                   </motion.div>
                 </div>
               </div>
             </section>
            
             <section className="py-24 bg-brand-900 relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent-500/10 rounded-full blur-[100px] translate-x-1/2 -translate-y-1/2"></div>
                
                <div className="container mx-auto px-6 relative z-10">
                   <div className="flex flex-col md:flex-row items-center justify-between gap-12 bg-white/5 rounded-[3rem] p-8 md:p-12 border border-white/10 backdrop-blur-sm shadow-2xl">
                      <div className="flex-1 text-left">
                         <div className="inline-flex items-center gap-2 bg-accent-500/20 text-accent-400 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-6 border border-accent-500/20">
                            <ShieldCheck size={16} />
                            <span>Official Member Access</span>
                         </div>
                         <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">Get Your Worshipper ID</h2>
                         <p className="text-brand-100/80 text-lg leading-relaxed mb-8 max-w-xl">
                            Verify your identity and generate your official City of Truth Ministries digital ID card. Access exclusive member resources, track your spiritual journey, and stay connected.
                         </p>
                         <div className="flex flex-wrap gap-4">
                            <Button 
                               onClick={() => setCurrentView(ViewState.ID_CARD)} 
                               variant="accent" 
                               className="px-8 py-4 text-base shadow-lg shadow-accent-500/20"
                            >
                               Verify Identity & Get ID <ArrowRight size={18} />
                            </Button>
                         </div>
                      </div>
                      
                      <motion.div 
                         initial={{ rotate: -5, y: 20 }}
                         whileInView={{ rotate: 0, y: 0 }}
                         transition={{ duration: 0.8 }}
                         className="relative w-full max-w-sm"
                      >
                         <div className="absolute inset-0 bg-gradient-to-br from-accent-500 to-brand-500 blur-[50px] opacity-40 rounded-full"></div>
                         <div className="relative bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 transform rotate-3 hover:rotate-0 transition-transform duration-500">
                             <div className="bg-white rounded-xl overflow-hidden shadow-xl">
                                <div className="bg-brand-900 h-16 relative overflow-hidden flex items-center px-4">
                                   <div className="absolute top-0 right-0 w-20 h-20 bg-accent-500/20 rounded-full blur-xl"></div>
                                   <div className="flex items-center gap-2 z-10">
                                      <div className="bg-white/10 p-1.5 rounded-lg"><Church size={16} className="text-amber-400"/></div>
                                      <div>
                                         <div className="text-[10px] text-white font-bold leading-none">CITY OF TRUTH</div>
                                         <div className="text-[8px] text-amber-300 mt-0.5">Ministries</div>
                                      </div>
                                   </div>
                                </div>
                                <div className="p-4 flex gap-4">
                                   <div className="w-16 h-20 bg-gray-100 rounded-lg flex items-center justify-center text-gray-300">
                                      <User size={24} />
                                   </div>
                                   <div className="space-y-2 flex-1">
                                      <div className="h-2 bg-gray-100 rounded w-3/4"></div>
                                      <div className="h-2 bg-gray-100 rounded w-1/2"></div>
                                      <div className="h-2 bg-gray-100 rounded w-full"></div>
                                   </div>
                                </div>
                                <div className="bg-gray-50 p-2 text-center border-t border-gray-100">
                                   <div className="text-[8px] text-brand-600 font-bold tracking-widest uppercase">Verified Member</div>
                                </div>
                             </div>
                         </div>
                      </motion.div>
                   </div>
                </div>
             </section>

            <TestimonialSection />
            <SpiritualAssistant />
          </motion.div>
        )}

        {currentView === ViewState.ABOUT_VALPARAI && (
           <motion.div 
             key="valparai"
             initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
             className="min-h-screen bg-slate-50 pt-32 pb-20"
           >
              <div className="container mx-auto px-6 max-w-4xl text-center mb-16 relative">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gradient-to-r from-blue-100/50 to-amber-100/50 rounded-full blur-[100px] -z-10 animate-pulse-slow"></div>

                  <motion.div 
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="inline-flex items-center gap-3 border border-amber-200 bg-white/60 backdrop-blur-sm px-8 py-3 rounded-full mb-10 shadow-lg shadow-amber-500/10"
                  >
                      <Sparkles size={16} className="text-amber-500 fill-amber-500 animate-pulse" />
                      <span className="uppercase tracking-[0.25em] font-bold text-xs text-amber-700">The 7th Heaven</span>
                      <Sparkles size={16} className="text-amber-500 fill-amber-500 animate-pulse" />
                  </motion.div>
                  
                  <motion.div 
                    variants={letterContainer}
                    initial="hidden"
                    animate="visible"
                    className="flex justify-center flex-wrap gap-1 md:gap-2 mb-6"
                  >
                    {Array.from("VALPARAI").map((char, index) => (
                      <motion.span 
                        key={index} 
                        variants={letterChild}
                        whileHover={{ y: -10, color: '#2563eb' }}
                        className="text-7xl md:text-9xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-br from-[#1e3a8a] via-[#3b82f6] to-[#1e3a8a] tracking-tight drop-shadow-sm inline-block transition-colors duration-300"
                        style={{ textShadow: '0 10px 30px rgba(59, 130, 246, 0.2)' }}
                      >
                        {char}
                      </motion.span>
                    ))}
                  </motion.div>
                  
                  <motion.div 
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.6, type: "spring" }}
                    className="bg-white/80 backdrop-blur-md px-10 py-3 rounded-2xl inline-block mb-12 shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-purple-100"
                  >
                      <h2 className="text-3xl font-tamil text-[#7e22ce] font-bold tracking-wide">வால்பாறை</h2>
                  </motion.div>
                  
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                    className="text-gray-600 font-serif text-xl md:text-2xl leading-relaxed max-w-2xl mx-auto"
                  >
                      A sanctuary in the clouds. <span className="italic font-bold text-brand-700">Valparai</span> is a scenic hill station in the Anaimalai Hills, offering a divine escape into nature's purest embrace. Located <span className="font-bold text-gray-900 bg-amber-100 px-2 py-0.5 rounded">3,474 feet</span> above sea level.
                  </motion.p>
              </div>

              <div className="container mx-auto px-6 max-w-5xl mb-24">
                  <motion.div 
                    variants={containerVariants}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-100px" }}
                    className="grid gap-6"
                  >
                    {[
                      { icon: Mountain, title: "Geography", text: "Located on the Anaimalai Hills range of the Western Ghats at an elevation of 3,474 ft (1,059 m). A pollution-free haven.", color: "blue" },
                      { icon: History, title: "Heritage", text: "First coffee planted in 1846 by K. Ramasamy Mudaliar. In 1890, W. Wintil began large scale tea & coffee cultivation.", color: "amber" },
                      { icon: Leaf, title: "Nature & Wildlife", text: "Part of Anaimalai Tiger Reserve. Home to Leopards, Elephants, Lion-tailed Macaques, Gaur, and Great Hornbills.", color: "emerald" },
                      { icon: TrendingUp, title: "Economy", text: "Driven by Tea and Coffee estates. Surrounded by dams like Aliyar and Sholayar, and hydro-electric power plants.", color: "purple" },
                      { icon: CloudRain, title: "Climate", text: "Mild tropical monsoon climate. One of the wettest places in TN. Summer: 15°C - 25°C. Winter: 10°C - 15°C.", color: "cyan" },
                      { icon: Plane, title: "How to Reach", text: "64 km from Pollachi with 40 hairpin bends. Nearest Airport: Coimbatore (102 km). Connected to Kerala via Malakkappara.", color: "rose" }
                    ].map((item, i) => (
                      <motion.div 
                        key={i}
                        variants={itemVariants} 
                        whileHover={{ y: -10, scale: 1.02 }}
                        className="bg-white/70 backdrop-blur-xl p-8 rounded-[2rem] shadow-sm hover:shadow-xl flex flex-col md:flex-row items-start gap-8 border border-white transition-all duration-300 group"
                      >
                          <div className={`w-20 h-20 rounded-2xl bg-${item.color}-50 flex items-center justify-center shrink-0 text-${item.color}-600`}>
                              <item.icon size={36} />
                          </div>
                          <div>
                              <h3 className={`text-3xl font-serif font-bold text-gray-900 mb-3 group-hover:text-${item.color}-700 transition-colors`}>{item.title}</h3>
                              <p className="text-gray-600 text-lg leading-relaxed mb-4">{item.text}</p>
                              <span className={`text-xs font-bold text-${item.color}-500 uppercase tracking-widest flex items-center gap-2`}>Read More <ArrowRight size={14} /></span>
                          </div>
                      </motion.div>
                    ))}
                  </motion.div>
              </div>
           </motion.div>
        )}

        {currentView === ViewState.MENORAH && <GoldenMenorah />}
        {currentView === ViewState.ID_CARD && <WorshipperIDCard />}

        {currentView === ViewState.CONTACT && (
          <motion.div key="contact" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32 pb-32">
            <div className="container mx-auto px-6 max-w-6xl">
              <div className="text-center mb-20">
                <h1 className="text-5xl md:text-7xl font-serif font-bold text-brand-950 mb-6 tracking-tight">Get In <span className="text-brand-600">Touch</span></h1>
                <p className="text-xl text-slate-500 font-light max-w-2xl mx-auto">We are here to support your spiritual journey. Reach out for prayer, information, or fellowship.</p>
              </div>

              <div className="grid lg:grid-cols-12 gap-16 items-start">
                <div className="lg:col-span-5 space-y-12">
                  <div className="grid grid-cols-1 gap-8">
                    {[
                      { icon: Phone, title: "Phone Support", info: "+91 80562 5478", desc: "Mon-Sat: 9am to 6pm" },
                      { icon: Mail, title: "Email Enquiries", info: "contact@cityoftruth.org", desc: "We reply within 24 hours" },
                      { icon: MapPin, title: "Valparai Sanctuary", info: "Hills of Valparai, Tamil Nadu", desc: "Main Campus" },
                      { icon: Clock, title: "Service Hours", info: "Sundays @ 9:00 AM", desc: "Tamil & English Worship" }
                    ].map((item, i) => (
                      <motion.div 
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex items-center gap-6 p-6 bg-white rounded-3xl shadow-lg border border-slate-50 hover:shadow-xl transition-all"
                      >
                        <div className="w-14 h-14 bg-brand-50 text-brand-600 rounded-2xl flex items-center justify-center shrink-0">
                          <item.icon size={24} />
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-brand-400 uppercase tracking-widest mb-1">{item.title}</p>
                          <p className="text-lg font-bold text-brand-950 mb-0.5">{item.info}</p>
                          <p className="text-xs text-slate-500">{item.desc}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="lg:col-span-7 bg-white p-10 md:p-14 rounded-[3rem] shadow-2xl border border-slate-50 relative"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-accent-50 rounded-bl-[100px] -z-10"></div>
                  <h2 className="text-3xl font-serif font-bold text-brand-950 mb-10">Send a Message</h2>
                  <form className="space-y-6" onSubmit={e => e.preventDefault()}>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Your Name</label>
                        <input type="text" placeholder="John Doe" className="w-full bg-slate-50 border border-slate-100 p-4 rounded-2xl outline-none focus:bg-white focus:ring-2 focus:ring-brand-500/20 transition-all font-medium" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
                        <input type="email" placeholder="john@example.com" className="w-full bg-slate-50 border border-slate-100 p-4 rounded-2xl outline-none focus:bg-white focus:ring-2 focus:ring-brand-500/20 transition-all font-medium" />
                      </div>
                    </div>
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Subject</label>
                        <select className="w-full bg-slate-50 border border-slate-100 p-4 rounded-2xl outline-none focus:bg-white transition-all font-medium">
                          <option>Prayer Request</option>
                          <option>General Inquiry</option>
                          <option>Membership</option>
                          <option>Media Access</option>
                        </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Your Message</label>
                      <textarea placeholder="How can we help you?" className="w-full bg-slate-50 border border-slate-100 p-4 rounded-2xl outline-none focus:bg-white focus:ring-2 focus:ring-brand-500/20 transition-all font-medium h-40"></textarea>
                    </div>
                    <Button fullWidth className="py-5 font-bold uppercase tracking-widest shadow-xl shadow-brand-500/30">
                      Send Spiritual Message <ArrowRight size={18} />
                    </Button>
                  </form>
                </motion.div>
              </div>
            </div>
          </motion.div>
        )}

        {currentView === ViewState.ABOUT && (
          <motion.div key="about" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-48 pb-32">
            <div className="container mx-auto px-6 text-center">
              <h1 className="text-6xl md:text-8xl font-serif font-bold text-brand-950 mb-8 tracking-tighter">Divine <span className="text-accent-600">Legacy</span></h1>
              <p className="text-2xl text-slate-500 max-w-3xl mx-auto font-light leading-relaxed mb-16">Since 2010, City of Truth Ministries has been a lighthouse in the hills of Valparai, dedicated to teaching the Word of God with uncompromising truth and love.</p>
              
              <div className="grid md:grid-cols-3 gap-12 text-left max-w-6xl mx-auto">
                {[
                  { title: "Empowerment", desc: "Equipping believers to walk in their divine calling through depth in scripture." },
                  { title: "Enlightenment", desc: "Revealing the mysteries of the Kingdom through prophetic teaching." },
                  { title: "Elevation", desc: "Raising a generation that worships in Spirit and in Truth." }
                ].map((item, i) => (
                  <div key={i} className="p-10 bg-white rounded-[2.5rem] shadow-xl border border-slate-100">
                    <div className="w-12 h-1 h-brand-500 bg-brand-500 rounded-full mb-8"></div>
                    <h3 className="text-2xl font-serif font-bold mb-4">{item.title}</h3>
                    <p className="text-slate-600 leading-relaxed font-normal">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {currentView === ViewState.MINISTRIES && (
          <motion.div key="ministries" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-48 pb-32">
             <div className="container mx-auto px-6 text-center text-brand-950">
               <h1 className="text-6xl md:text-8xl font-serif font-bold mb-8 tracking-tighter">Impact <span className="text-accent-600">Ministries</span></h1>
               <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10 text-left mt-16">
                 {[
                   { icon: <Music />, title: "Worship Arts", desc: "Leading the congregation into encounter with God through excellence in music and atmosphere." },
                   { icon: <Users />, title: "Next Gen", desc: "Equipping the youth and children with Biblical boldness to lead in a complex world." },
                   { icon: <Heart />, title: "Mercy Missions", desc: "Extending Christ's hands to the broken and needy in the local community and beyond." }
                 ].map((ministry, idx) => (
                   <div key={idx} className="bg-white p-12 rounded-[3rem] shadow-xl border border-slate-100 group hover:-translate-y-2 transition-all duration-300">
                     <div className="w-16 h-16 rounded-2xl mb-10 flex items-center justify-center bg-brand-600 text-white shadow-lg group-hover:scale-110 transition-transform">
                        {React.cloneElement(ministry.icon as React.ReactElement, { size: 30 })}
                     </div>
                     <h3 className="text-2xl font-bold mb-5 uppercase tracking-wide font-serif">{ministry.title}</h3>
                     <p className="text-slate-500 leading-relaxed mb-10 text-sm font-normal">{ministry.desc}</p>
                     <Button variant="ghost" className="p-0 text-brand-600 !justify-start">Learn More <ArrowRight size={16} /></Button>
                   </div>
                 ))}
               </div>
             </div>
          </motion.div>
        )}

        {currentView === ViewState.HEBREW && (
          <motion.div 
            key="hebrew" 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            className="min-h-screen pt-32 pb-20 relative overflow-hidden text-center bg-black"
          >
             <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent opacity-50"></div>
             <div className="absolute inset-0 z-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30 mix-blend-overlay"></div>
             
             <motion.div
               initial={{ y: -20, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               className="relative z-10"
             >
                <Scroll size={48} className="text-amber-500 mx-auto mb-6" />
                <h1 className="text-5xl md:text-8xl font-serif font-bold tracking-tight mb-4 text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600">
                  Lashon HaKodesh
                </h1>
                <p className="text-amber-500/80 text-xl mb-16 font-serif italic max-w-2xl mx-auto uppercase tracking-[0.3em]">
                  Hebrew & Ancient Aramaic
                </p>
             </motion.div>

             <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-8 max-w-7xl mx-auto mt-16 px-6 relative z-10">
                 {hebrewLetters.map((item, index) => (
                   <motion.div 
                    key={index} 
                    whileHover={{ scale: 1.05, y: -5 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-black border border-amber-900/30 rounded-[2rem] p-10 flex flex-col items-center backdrop-blur-md shadow-[0_0_40px_rgba(251,191,36,0.05)] hover:shadow-[0_0_60px_rgba(251,191,36,0.15)] hover:border-amber-500/50 transition-all cursor-pointer group relative overflow-hidden"
                   >
                      <div className="absolute top-0 right-0 p-2 opacity-10"><Award size={32} className="text-amber-500" /></div>
                      <span className="text-7xl font-serif mb-6 text-amber-100 group-hover:text-amber-400 transition-colors drop-shadow-[0_0_15px_rgba(251,191,36,0.3)]">{item.letter}</span>
                      <span className="text-lg font-bold text-amber-500 uppercase tracking-widest mb-1">{item.name}</span>
                      <span className="text-[10px] text-amber-200/40 uppercase tracking-[0.2em] mb-4">{item.sound}</span>
                      <div className="pt-4 border-t border-amber-900/30 w-full">
                        <span className="text-[10px] text-amber-100/60 uppercase tracking-widest block">{item.meaning}</span>
                      </div>
                   </motion.div>
                 ))}
             </div>
             
             <div className="mt-32 max-w-4xl mx-auto p-12 bg-white/5 border border-amber-500/10 rounded-[3rem] backdrop-blur-md text-center relative z-10">
                <Flame size={40} className="text-amber-500 mx-auto mb-6 animate-pulse" />
                <h3 className="text-3xl font-serif font-bold text-amber-100 mb-6">The Language of Creation</h3>
                <p className="text-amber-100/60 leading-relaxed text-lg italic">
                  "In the beginning was the Word, and the Word was with God..." 
                  Our Hebrew & Aramaic studies delve into the ancient pictographic meanings of each character, revealing the heart of the Father hidden in every stroke.
                </p>
             </div>
          </motion.div>
        )}
        </AnimatePresence>
      </main>

      <footer className="bg-brand-950 text-white pt-32 pb-16 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-600 via-accent-400 to-brand-600"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-4 gap-16 mb-24">
            <div className="col-span-1 md:col-span-1">
               <div className="flex items-center gap-4 mb-10">
                 <div className="bg-brand-600 p-3 rounded-2xl text-white border border-brand-500"><Church size={30} strokeWidth={1.5} /></div>
                 <div><h2 className="font-serif font-bold text-2xl uppercase tracking-tight">City of Truth</h2><p className="text-[10px] text-accent-400 font-bold tracking-[0.3em] uppercase mt-1">Ministries</p></div>
               </div>
               <p className="text-brand-100/50 text-sm leading-relaxed mb-10 font-normal">An ecosystem of grace designed to empower, enlighten, and elevate every soul we encounter.</p>
               <div className="flex gap-5">
                 {[Mail, Phone, Youtube, Instagram].map((Icon, i) => (
                    <button key={i} className="bg-white/5 hover:bg-accent-500 hover:text-brand-950 p-3 rounded-xl transition-all border border-white/5"><Icon size={20} /></button>
                 ))}
               </div>
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase tracking-[0.3em] mb-10 text-accent-300">Navigation</h3>
              <ul className="space-y-6 text-brand-100/60 text-xs font-semibold uppercase tracking-widest">
                {['Home', 'About Us', 'Ministries', 'Contact'].map((link, i) => (
                  <li key={i}><button onClick={() => setCurrentView(link.toUpperCase() === 'ABOUT US' ? ViewState.ABOUT : link.toUpperCase() as any)} className="hover:text-white transition-all flex items-center gap-3"><span className="w-1.5 h-1.5 bg-accent-500/40 rounded-full"></span> {link}</button></li>
                ))}
              </ul>
            </div>
            <div>
               <h3 className="font-bold text-sm uppercase tracking-[0.3em] mb-10 text-brand-400">Services</h3>
               <ul className="space-y-6 text-brand-100/60 text-xs font-semibold uppercase tracking-widest">
                {['Entrust Card', 'Hebrew Study', 'Prayer Line'].map((link, i) => (
                  <li key={i}><button className="hover:text-white transition-all flex items-center gap-3"><span className="w-1.5 h-1.5 bg-brand-500/40 rounded-full"></span> {link}</button></li>
                ))}
               </ul>
            </div>
            <div className="bg-white/5 p-10 rounded-[2.5rem] border border-white/5 backdrop-blur-sm">
              <h3 className="font-bold text-sm uppercase tracking-[0.3em] mb-8 text-white">Newsletter</h3>
              <div className="flex flex-col gap-4">
                <input type="email" placeholder="Email Address" className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-xs font-medium text-white focus:outline-none" />
                <Button fullWidth variant="primary" className="!rounded-2xl py-4 font-bold tracking-widest uppercase text-[10px]">Subscribe</Button>
              </div>
            </div>
          </div>
          <div className="border-t border-white/5 pt-12 text-[10px] font-bold uppercase tracking-[0.4em] text-brand-100/30 flex justify-between items-center">
            <p>&copy; 2024 City of Truth Ministries • Valparai Sanctuary</p>
            <div className="flex gap-12"><a href="#" className="hover:text-white">Privacy Policy</a><a href="#" className="hover:text-white">Terms of Service</a></div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;