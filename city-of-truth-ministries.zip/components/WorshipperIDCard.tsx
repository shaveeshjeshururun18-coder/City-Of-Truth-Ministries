import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Church, RefreshCw, User, ShieldCheck, X, Phone, Mail, MapPin, UploadCloud, CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from './Button';

interface EntrustCardProps {
    name?: string;
    email?: string;
    dob?: string;
    location?: string;
    bloodGroup?: string;
    emergency?: string;
    memberSince?: string;
    role?: string;
    uniqueId?: string;
    photo?: string;
    gender?: string;
    className?: string;
}

export const EntrustCard3D: React.FC<EntrustCardProps> = ({
    name = "John Doe",
    email = "john@example.com",
    dob = "01/01/1990",
    location = "Valparai",
    bloodGroup = "O+ve",
    emergency = "+91 80561 25478",
    memberSince = "2024",
    role = "Member",
    uniqueId = "COT-SAMPLE",
    gender = "Male",
    photo,
    className = ""
}) => {
    const [isFlipped, setIsFlipped] = useState(false);

    const fullDetails = `CITY OF TRUTH MINISTRIES\nID: ${uniqueId}\nName: ${name}\nRole: ${role}`.trim();
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(fullDetails)}&bgcolor=ffffff&color=2c298c&margin=2`;

    return (
        <div 
            className={`relative w-full max-w-[320px] h-[520px] cursor-pointer mx-auto ${className}`}
            onClick={() => setIsFlipped(!isFlipped)}
            style={{ perspective: "1000px" }}
        >
            <motion.div
                className="w-full h-full relative"
                style={{ transformStyle: "preserve-3d" }}
                animate={{ rotateY: isFlipped ? 180 : 0 }}
                transition={{ duration: 0.6, ease: "easeInOut" }}
            >
                {/* FRONT FACE */}
                <div className="absolute inset-0 bg-white rounded-2xl overflow-hidden backface-hidden border border-gray-200 shadow-2xl flex flex-col" style={{ backfaceVisibility: 'hidden' }}>
                    <div className="bg-brand-900 text-white p-4 relative overflow-hidden shrink-0">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-accent-400/20 rounded-full blur-2xl"></div>
                        <div className="flex items-center gap-3 relative z-10">
                            <div className="bg-white/10 p-2 rounded-lg border border-white/10">
                                <Church size={20} className="text-accent-300" />
                            </div>
                            <div>
                                <h2 className="font-bold text-xs uppercase tracking-wider">City of Truth Ministries</h2>
                                <p className="text-[10px] text-accent-200 font-medium mt-0.5">சத்திய நகரம் ஊழியங்கள்</p>
                            </div>
                        </div>
                    </div>

                    <div className="bg-accent-50 py-1.5 text-center border-b border-accent-100 shrink-0">
                        <p className="text-accent-700 font-bold text-[10px] uppercase tracking-widest">ENTRUST CARD</p>
                    </div>

                    <div className="p-6 flex-1 flex flex-col relative">
                        <div className="flex justify-between items-start mb-6">
                            <div className="text-[10px] font-mono font-bold text-brand-800 bg-brand-50 px-2 py-1 rounded border border-brand-100">
                                ID: {uniqueId}
                            </div>
                            <div className="w-20 h-24 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-center text-slate-300 overflow-hidden shadow-inner">
                                {photo ? <img src={photo} alt="P" className="w-full h-full object-cover" /> : <User size={40} />}
                            </div>
                        </div>

                        <div className="space-y-4 flex-1">
                            <div>
                                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Full Member Name</label>
                                <p className="text-sm font-bold text-brand-900 uppercase leading-tight">{name || '—'}</p>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Birth Date</label>
                                    <p className="text-xs font-semibold text-slate-700">{dob || '—'}</p>
                                </div>
                                <div>
                                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Blood Group</label>
                                    <p className="text-xs font-semibold text-slate-700">{bloodGroup || '—'}</p>
                                </div>
                            </div>
                            <div>
                                <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Location</label>
                                <p className="text-xs font-semibold text-slate-700">{location || '—'}</p>
                            </div>
                        </div>

                        <div className="mt-auto flex justify-between items-end pt-4 border-t border-slate-50">
                            <p className="text-[9px] text-slate-400 italic font-serif leading-tight">"Faith • Truth • Love"</p>
                            <div className="bg-white p-1 border border-slate-100 rounded-md">
                                <img src={qrCodeUrl} alt="QR" className="w-14 h-14" />
                            </div>
                        </div>
                    </div>

                    <div className="bg-brand-950 p-2 text-center border-t-2 border-accent-400">
                        <span className="text-[8px] font-bold tracking-widest text-accent-300 uppercase">Official Verification Required</span>
                    </div>
                </div>

                {/* BACK FACE */}
                <div 
                    className="absolute inset-0 bg-gradient-to-br from-brand-900 to-indigo-950 rounded-2xl overflow-hidden border border-brand-900 shadow-2xl flex flex-col p-8 text-center" 
                    style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
                >
                    <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
                    <div className="relative z-10 flex-1 flex flex-col items-center justify-center">
                        <div className="bg-white/10 p-3 rounded-full mb-6 border border-white/20">
                            <Church size={32} className="text-accent-300" />
                        </div>
                        <h3 className="text-lg font-serif font-bold text-white mb-4">Ministry Covenant</h3>
                        <p className="text-indigo-100 text-sm italic font-serif leading-relaxed mb-8">
                            "But my servant Moses is not so; he is faithful in all mine house. With him will I speak mouth to mouth."
                            <span className="block mt-2 text-accent-400 font-sans font-bold not-italic text-[10px] tracking-widest uppercase">- Numbers 12:7-8</span>
                        </p>
                        <div className="w-full text-left space-y-3 bg-black/20 p-4 rounded-xl border border-white/5">
                            <div className="flex items-center gap-3 text-indigo-100 text-xs">
                                <Phone size={14} className="text-accent-400" /> <span>+91 80561 25478</span>
                            </div>
                            <div className="flex items-center gap-3 text-indigo-100 text-xs">
                                <Mail size={14} className="text-accent-400" /> <span className="truncate">faithfulfellowship8@gmail.com</span>
                            </div>
                        </div>
                    </div>
                    <p className="relative z-10 text-[9px] text-indigo-400 mt-4">Authorized for spiritual community access only.</p>
                </div>
            </motion.div>
        </div>
    );
};

export const WorshipperIDCard: React.FC = () => {
  const [uniqueId, setUniqueId] = useState('');
  const [formData, setFormData] = useState({
    name: 'S. Shaveesh Jeshurun',
    email: 'shaveesh@example.com',
    dob: '1995-08-20',
    location: 'Valparai',
    bloodGroup: 'O+ve',
    emergency: '9876543210',
    memberSince: '2015',
    gender: 'Male',
    role: 'Media Team'
  });
  const [photo, setPhoto] = useState<string | undefined>(undefined);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    setUniqueId(`COT-${Math.floor(1000 + Math.random() * 9000)}`);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const url = URL.createObjectURL(e.target.files[0]);
        setPhoto(url);
    }
  };

  return (
    <section className="min-h-screen pt-40 pb-20 bg-slate-50 relative overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-brand-100 px-4 py-1.5 rounded-full text-brand-700 border border-brand-200 mb-6">
            <ShieldCheck size={14} />
            <span className="text-[10px] font-bold tracking-widest uppercase">Official Verification Service</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-950 mb-6 tracking-tight">Identity Generation</h1>
          <p className="text-lg text-gray-500 font-normal">Review and generate your digital City of Truth Entrust Card below.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start max-w-6xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100"
          >
            <h3 className="text-xl font-bold text-brand-950 mb-8 flex items-center gap-3 font-serif">
              <User size={22} className="text-accent-500" /> Member Details
            </h3>
            
            <div className="space-y-6">
                <div className="relative group">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Photo Upload</label>
                    <div className="mt-2 border-2 border-dashed border-slate-200 rounded-2xl p-4 transition-all hover:border-accent-400 hover:bg-accent-50/30">
                        <input type="file" onChange={handlePhotoUpload} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400">
                                {photo ? <img src={photo} className="w-full h-full object-cover rounded-xl" /> : <UploadCloud size={20} />}
                            </div>
                            <span className="text-sm font-medium text-slate-500">{photo ? "Photo added" : "Click to upload your image"}</span>
                        </div>
                    </div>
                </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Full Name</label>
                  <input name="name" value={formData.name} onChange={handleInputChange} type="text" className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-accent-500/20 outline-none transition-all text-sm font-medium" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Date of Birth</label>
                  <input name="dob" value={formData.dob} onChange={handleInputChange} type="date" className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl outline-none text-sm" />
                </div>
              </div>

              <div className="pt-6 flex gap-4">
                <Button onClick={() => setUniqueId(`COT-${Math.floor(1000 + Math.random() * 9000)}`)} variant="secondary" className="flex-1 py-4 text-[10px] font-bold uppercase tracking-widest">
                   <RefreshCw size={16} /> Random ID
                </Button>
                <Button onClick={() => { setIsProcessing(true); setTimeout(() => setIsProcessing(false), 1500); }} variant="primary" className="flex-[2] py-4 text-[10px] font-bold uppercase tracking-widest" disabled={isProcessing}>
                   {isProcessing ? "Validating..." : <><CheckCircle size={16} /> Request Approval</>}
                </Button>
              </div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center">
             <p className="text-xs font-bold text-brand-600 mb-6 flex items-center gap-2 uppercase tracking-widest">
                <CheckCircle size={14} /> Interactive Preview
             </p>
             <EntrustCard3D {...formData} uniqueId={uniqueId} photo={photo} />
             <p className="mt-8 text-xs text-slate-400 text-center font-medium max-w-xs leading-relaxed uppercase tracking-wider">
                Click the card to view the <br/>Ministry Covenant (Back face)
             </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};